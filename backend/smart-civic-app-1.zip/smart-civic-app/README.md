# Smart Civic Complaint App

Backend for an AI-powered civic complaint system.

## Features
- PostgreSQL complaint database
- AI category-ready complaint API
- Automatic department routing
- Location-based duplicate detection
- Admin dashboard
- Complaint status management

## Categories
POTHOLE, GARBAGE, STREETLIGHT, WATER_LEAKAGE, DAMAGED_ROAD, DRAINAGE

## Department routing
- POTHOLE -> Road
- DAMAGED_ROAD -> Road
- GARBAGE -> Sanitation
- STREETLIGHT -> Electricity
- WATER_LEAKAGE -> Water
- DRAINAGE -> Drainage

## Run
1. Create a PostgreSQL database named `smart_civic`.
2. Run `database/schema.sql`.
3. Copy `.env.example` to `.env` and add your database password.
4. Run `npm install`.
5. Run `npm start`.
6. Open `admin/index.html`.

## API
POST /api/complaints
GET /api/admin/stats
GET /api/admin/complaints
PATCH /api/admin/complaints/:id/status
